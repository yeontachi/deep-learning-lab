import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision import datasets, transforms
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix

# 1. 디바이스 설정
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Using device:", DEVICE)

# 2. 하이퍼파라미터
BATCH_SIZE = 32
EPOCHS = 10

# 3. 데이터셋 불러오기 (이미지 크기 128x128로 변경)
transform = transforms.Compose([
    transforms.Resize(128),
    transforms.ToTensor()
])

train_dataset = datasets.MNIST(root="../data/MNIST", train=True, download=True, transform=transform)
test_dataset = datasets.MNIST(root="../data/MNIST", train=False, download=True, transform=transform)

train_loader = torch.utils.data.DataLoader(dataset=train_dataset, batch_size=BATCH_SIZE, shuffle=True)
test_loader = torch.utils.data.DataLoader(dataset=test_dataset, batch_size=BATCH_SIZE, shuffle=False)

# 4. CNN 모델 정의 (Conv + Pool 3쌍)
class CNN_Depthwise5(nn.Module):
    def __init__(self):
        super(CNN_Depthwise5, self).__init__()

        def dw_sep(in_ch, out_ch):
            return nn.Sequential(
                nn.Conv2d(in_ch, in_ch, kernel_size=3, padding=1, groups=in_ch),
                nn.Conv2d(in_ch, out_ch, kernel_size=1),
                nn.BatchNorm2d(out_ch),
                nn.ReLU()
            )

        self.conv1 = dw_sep(1, 16)      # 128x128
        self.pool1 = nn.MaxPool2d(2)    # → 64x64

        self.conv2 = dw_sep(16, 32)     # 64x64
        self.pool2 = nn.MaxPool2d(2)    # → 32x32

        self.conv3 = dw_sep(32, 64)     # 32x32
        self.pool3 = nn.MaxPool2d(2)    # → 16x16

        self.conv4 = dw_sep(64, 128)    # 16x16
        self.pool4 = nn.MaxPool2d(2)    # → 8x8

        self.conv5 = dw_sep(128, 256)   # 8x8
        self.pool5 = nn.MaxPool2d(2)    # → 4x4

        self.fc1 = nn.Linear(256 * 4 * 4, 128)
        self.fc2 = nn.Linear(128, 10)

    def forward(self, x):
        x = self.pool1(self.conv1(x))
        x = self.pool2(self.conv2(x))
        x = self.pool3(self.conv3(x))
        x = self.pool4(self.conv4(x))
        x = self.pool5(self.conv5(x))

        x = x.view(x.size(0), -1)
        x = F.relu(self.fc1(x))
        x = self.fc2(x)
        return x

# 5. 모델, 옵티마이저, 손실 함수
model = CNN_Depthwise5().to(DEVICE)
optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
criterion = nn.CrossEntropyLoss()

# 6. 학습 함수
def train(model, train_loader, optimizer, log_interval):
    model.train()
    for batch_idx, (image, label) in enumerate(train_loader):
        image, label = image.to(DEVICE), label.to(DEVICE)
        optimizer.zero_grad()
        output = model(image)
        loss = criterion(output, label)
        loss.backward()
        optimizer.step()
        if batch_idx % log_interval == 0:
            print("Train Epoch: {} [{}/{} ({:.0f}%)]\tLoss: {:.6f}".format(
                epoch, batch_idx * len(image), len(train_loader.dataset),
                100. * batch_idx / len(train_loader), loss.item()))

# 7. 평가 함수
def evaluate(model, test_loader):
    model.eval()
    test_loss = 0
    correct = 0
    with torch.no_grad():
        for image, label in test_loader:
            image, label = image.to(DEVICE), label.to(DEVICE)
            output = model(image)
            test_loss += criterion(output, label).item()
            pred = output.argmax(dim=1)
            correct += pred.eq(label).sum().item()
    test_loss /= len(test_loader.dataset) / BATCH_SIZE
    accuracy = 100. * correct / len(test_loader.dataset)
    return test_loss, accuracy

# 8. 학습 루프 실행
for epoch in range(1, EPOCHS + 1):
    train(model, train_loader, optimizer, log_interval=200)
    test_loss, test_accuracy = evaluate(model, test_loader)
    print(f"\n[EPOCH {epoch}] Test Loss: {test_loss:.4f}, Test Accuracy: {test_accuracy:.2f}%\n")

# 9. 최종 평가
final_test_loss, final_test_accuracy = evaluate(model, test_loader)
print("Final Test Loss: {:.4f}".format(final_test_loss))
print("Final Test Accuracy: {:.2f}%".format(final_test_accuracy))

# 10. Confusion Matrix 시각화
def get_all_preds(model, loader):
    model.eval()
    all_preds = torch.tensor([], dtype=torch.long).to(DEVICE)
    all_labels = torch.tensor([], dtype=torch.long).to(DEVICE)
    with torch.no_grad():
        for image, label in loader:
            image, label = image.to(DEVICE), label.to(DEVICE)
            output = model(image)
            preds = output.argmax(dim=1)
            all_preds = torch.cat((all_preds, preds), dim=0)
            all_labels = torch.cat((all_labels, label), dim=0)
    return all_preds.cpu().numpy(), all_labels.cpu().numpy()

def plot_confusion_matrix(model, loader, class_names):
    y_pred, y_true = get_all_preds(model, loader)
    cm = confusion_matrix(y_true, y_pred)
    plt.figure(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
                xticklabels=class_names, yticklabels=class_names)
    plt.xlabel('Predicted')
    plt.ylabel('True')
    plt.title('Confusion Matrix')
    plt.tight_layout()
    plt.show()

class_names = [str(i) for i in range(10)]

plot_confusion_matrix(model, test_loader, class_names)